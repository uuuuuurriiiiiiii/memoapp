# 我的备忘录（MemoApp）

一个使用 Kotlin + Jetpack 全家桶开发的 Android 备忘录 App，支持增删改查、本地持久化、搜索、置顶、分类标签、到期提醒和深色模式。

## 功能清单

| 功能 | 说明 |
|------|------|
| 新建 / 编辑 / 删除备忘 | 点击右下角 + 新建；点击卡片进入编辑；卡片右上角垃圾桶删除（带确认弹窗） |
| 本地持久化 | Room（SQLite）数据库，重启 App 数据不丢失 |
| 搜索 | 工具栏搜索框，按标题和正文实时模糊匹配 |
| 置顶 | 卡片图钉图标，置顶项永远排在列表最前 |
| 分类标签 | 顶部分类 Chips 筛选；编辑页可下拉选预置分类，也可自由输入新分类 |
| 到期提醒 | 编辑页设置日期 + 时间，到点弹系统通知，点击通知直达该条备忘；Android 12+ 无精确闹钟权限时自动降级 |
| 深色模式 | Material3 DayNight 主题，跟随系统自动切换 |

## 技术栈

- 语言：Kotlin 1.9.24
- UI：Material 3、ConstraintLayout、RecyclerView、ViewBinding、ChipGroup
- 架构：Room（Entity / DAO / Database / Repository / ViewModel）+ Flow/StateFlow
- 异步：Kotlin 协程
- 提醒：AlarmManager + BroadcastReceiver + NotificationChannel
- 构建：AGP 8.5.2 + Gradle 8.7 + KSP

## 目录结构

```
MemoApp/
├── settings.gradle.kts / build.gradle.kts / gradle.properties
├── gradlew / gradlew.bat / gradle/wrapper/
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/example/memoapp/
        │   ├── data/          # 数据层
        │   │   ├── Memo.kt            # Room 实体
        │   │   ├── MemoDao.kt         # DAO（Flow 查询）
        │   │   ├── MemoDatabase.kt    # 数据库单例
        │   │   ├── MemoRepository.kt  # 仓库
        │   │   └── MemoViewModel.kt   # ViewModel
        │   ├── reminder/
        │   │   └── ReminderScheduler.kt  # AlarmManager 调度
        │   ├── MainActivity.kt        # 列表页
        │   ├── EditMemoActivity.kt    # 编辑页
        │   ├── MemoAdapter.kt         # 列表适配器
        │   └── ReminderReceiver.kt    # 闹钟广播 → 通知
        └── res/
            ├── layout/   # activity_main / activity_edit_memo / item_memo
            ├── values/   # 字符串、颜色、主题
            ├── values-night/  # 深色模式配色
            ├── drawable/  # 图标
            └── menu/      # 搜索菜单
```

## 在 Android Studio 中运行

1. 打开 Android Studio，选择 **Open**，选中 `MemoApp` 文件夹（工程根目录，含 `settings.gradle.kts`）。
2. 等待 Gradle Sync 完成（首次会自动下载依赖，需要联网，约几分钟）。
3. 连接模拟器或真机（真机需开启 USB 调试），点击绿色 **Run ▶**。
4. 首次安装后打开 App：新建一条带提醒时间的备忘 → 回到系统时间到点时即可看到通知。

> 如果 Sync 报错：① 确认 Android Studio 版本较新（建议 Koala 2024.1 及以上，自带 JDK 17）；② 如提示 Gradle 版本问题，在 `File → Project Structure → Gradle` 中使用 Gradle wrapper 的 8.7。

## 权限说明

- `POST_NOTIFICATIONS`：Android 13+ 发送通知需动态授权（App 启动时自动申请）。
- `SCHEDULE_EXACT_ALARM`：Android 12+ 精确闹钟权限。若被系统拒绝，提醒自动降级为非精确（时间可能偏差几分钟），仍会触发。

## 主要 API（版本）

- minSdk 26（Android 8.0）/ targetSdk 34
- Room 2.6.1、Lifecycle 2.8.4、Material 1.12.0、core-ktx 1.13.1
- 协程 1.8.1

## 备注

- 数据库文件 `memo_db` 存于应用私有目录，卸载 App 后数据清除。
- 列表排序规则：置顶优先，其次按最后修改时间倒序。
- 本项目已通过代码一致性静态校验（控件 ID / 资源引用 / XML 格式），由于环境无 Android SDK，未在本机编译运行；首次 Sync 若有报错，按提示贴回来即可快速修复。
