package com.example.memoapp

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.memoapp.data.Memo
import com.example.memoapp.data.MemoDatabase
import com.example.memoapp.data.MemoRepository
import com.example.memoapp.databinding.ActivityEditMemoBinding
import com.example.memoapp.reminder.ReminderScheduler
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * 编辑页：新建/编辑备忘、分类、到期提醒、删除
 */
class EditMemoActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MEMO_ID = "extra_memo_id"
        private const val NO_MEMO_ID = -1L
    }

    private lateinit var binding: ActivityEditMemoBinding
    private lateinit var repository: MemoRepository

    private val presetCategories = listOf("默认", "工作", "学习", "生活", "个人")
    private val timeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())

    private var memoId: Long = NO_MEMO_ID
    private var currentMemo: Memo? = null
    private var remindAt: Long? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditMemoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = MemoRepository(MemoDatabase.getInstance(this).memoDao())
        memoId = intent.getLongExtra(EXTRA_MEMO_ID, NO_MEMO_ID)

        setupToolbar()
        setupCategoryInput()
        setupReminder()
        setupSave()
        setupDelete()

        if (memoId != NO_MEMO_ID) loadMemo()
    }

    // ---------- 工具栏 ----------
    private fun setupToolbar() {
        binding.toolbarEdit.setNavigationOnClickListener { finish() }
        if (memoId != NO_MEMO_ID) {
            binding.toolbarEdit.title = getString(R.string.edit_memo)
        }
    }

    // ---------- 分类输入（预置下拉 + 可自由输入） ----------
    private fun setupCategoryInput() {
        binding.actCategory.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_list_item_1, presetCategories)
        )
    }

    // ---------- 加载已有备忘 ----------
    private fun loadMemo() {
        lifecycleScope.launch {
            val memo = repository.getById(memoId)
            if (memo == null) {
                finish()
                return@launch
            }
            currentMemo = memo
            binding.etTitle.setText(memo.title)
            binding.etContent.setText(memo.content)
            binding.actCategory.setText(memo.category, false)
            remindAt = memo.remindAt
            updateReminderUi()
            binding.btnDelete.visibility = View.VISIBLE
        }
    }

    // ---------- 到期提醒 ----------
    private fun setupReminder() {
        binding.switchRemind.setOnCheckedChangeListener { _, checked ->
            when {
                checked && remindAt == null -> pickRemindTime()
                !checked -> {
                    remindAt = null
                    binding.tvRemindTime.text = getString(R.string.remind_pick)
                }
            }
        }
        binding.btnPickTime.setOnClickListener {
            if (binding.switchRemind.isChecked) pickRemindTime()
        }
    }

    private fun pickRemindTime() {
        val now = Calendar.getInstance()
        DatePickerDialog(
            this,
            { _, year, month, day ->
                TimePickerDialog(
                    this,
                    { _, hour, minute ->
                        val target = Calendar.getInstance().apply {
                            set(year, month, day, hour, minute, 0)
                            set(Calendar.MILLISECOND, 0)
                        }
                        if (target.timeInMillis <= System.currentTimeMillis()) {
                            Toast.makeText(
                                this, R.string.reminder_must_be_future, Toast.LENGTH_SHORT
                            ).show()
                            remindAt = null
                            updateReminderUi()
                        } else {
                            remindAt = target.timeInMillis
                            updateReminderUi()
                        }
                    },
                    now.get(Calendar.HOUR_OF_DAY),
                    now.get(Calendar.MINUTE),
                    true
                ).show()
            },
            now.get(Calendar.YEAR),
            now.get(Calendar.MONTH),
            now.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun updateReminderUi() {
        if (remindAt != null) {
            binding.switchRemind.isChecked = true
            binding.tvRemindTime.text =
                getString(R.string.remind_time_prefix) + timeFormat.format(Date(remindAt!!))
        } else {
            binding.switchRemind.isChecked = false
            binding.tvRemindTime.text = getString(R.string.remind_pick)
        }
    }

    // ---------- 保存 ----------
    private fun setupSave() {
        binding.btnSave.setOnClickListener {
            val title = binding.etTitle.text?.toString().orEmpty()
            val content = binding.etContent.text?.toString().orEmpty()
            if (title.isBlank() && content.isBlank()) {
                Toast.makeText(this, R.string.empty_validation, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val category = binding.actCategory.text?.toString()?.trim().orEmpty().ifBlank { "默认" }

            lifecycleScope.launch {
                val savedId: Long
                if (currentMemo != null) {
                    val updated = currentMemo!!.copy(
                        title = title,
                        content = content,
                        category = category,
                        remindAt = remindAt,
                        updatedAt = System.currentTimeMillis()
                    )
                    repository.update(updated)
                    savedId = updated.id
                } else {
                    val now = System.currentTimeMillis()
                    savedId = repository.insert(
                        Memo(
                            title = title,
                            content = content,
                            category = category,
                            remindAt = remindAt,
                            createdAt = now,
                            updatedAt = now
                        )
                    )
                }
                handleReminder(savedId, title, content)
                finish()
            }
        }
    }

    /** 保存后同步设置/取消闹钟提醒 */
    private fun handleReminder(id: Long, title: String, content: String) {
        val reminder = remindAt
        if (reminder != null) {
            ReminderScheduler.schedule(this, id, title, content, reminder)
        } else {
            ReminderScheduler.cancel(this, id)
        }
    }

    // ---------- 删除 ----------
    private fun setupDelete() {
        binding.btnDelete.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.delete_confirm_title)
                .setMessage(R.string.delete_confirm_message)
                .setPositiveButton(R.string.confirm) { _, _ ->
                    lifecycleScope.launch {
                        currentMemo?.let { memo ->
                            repository.delete(memo)
                            ReminderScheduler.cancel(this@EditMemoActivity, memo.id)
                        }
                        finish()
                    }
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
    }
}
