package com.example.memoapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.memoapp.data.Memo
import com.example.memoapp.data.MemoDatabase
import com.example.memoapp.data.MemoRepository
import com.example.memoapp.data.MemoViewModel
import com.example.memoapp.databinding.ActivityMainBinding
import com.example.memoapp.reminder.ReminderScheduler
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch

/**
 * 主界面：备忘列表 + 搜索 + 分类筛选 + 置顶/删除操作
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MemoViewModel
    private lateinit var adapter: MemoAdapter

    /** 预置分类（编辑页可自由输入新分类） */
    private val presetCategories = listOf("全部", "默认", "工作", "学习", "生活", "个人")

    private val requestNotificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            // Android 13+ 通知权限申请结果，无需额外处理
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val repository = MemoRepository(MemoDatabase.getInstance(this).memoDao())
        viewModel = ViewModelProvider(this, MemoViewModel.Factory(repository))[MemoViewModel::class.java]

        setSupportActionBar(binding.toolbar)
        setupCategoryChips()
        setupRecycler()
        setupFab()
        observeMemos()
        requestNotificationPermissionIfNeeded()
    }

    // ---------- 分类筛选 Chips ----------
    private fun setupCategoryChips() {
        presetCategories.forEachIndexed { index, name ->
            val chip = Chip(this).apply {
                id = View.generateViewId()
                text = name
                isCheckable = true
                isChecked = index == 0 // 默认选中"全部"
            }
            binding.chipGroupCategory.addView(chip)
        }

        binding.chipGroupCategory.setOnCheckedStateChangeListener { group, checkedIds ->
            if (checkedIds.isEmpty()) return@setOnCheckedStateChangeListener
            val chip = group.findViewById<Chip>(checkedIds.first())
            val name = chip.text.toString()
            // "全部" 表示不过滤分类
            viewModel.setCategory(if (name == "全部") null else name)
        }
    }

    // ---------- 列表 ----------
    private fun setupRecycler() {
        adapter = MemoAdapter(
            onItemClick = { memo -> openEditor(memo.id) },
            onPinClick = { memo -> togglePin(memo) },
            onDeleteClick = { memo -> confirmDelete(memo) }
        )
        binding.recyclerMemo.layoutManager = LinearLayoutManager(this)
        binding.recyclerMemo.adapter = adapter
    }

    private fun openEditor(memoId: Long) {
        startActivity(
            Intent(this, EditMemoActivity::class.java)
                .putExtra(EditMemoActivity.EXTRA_MEMO_ID, memoId)
        )
    }

    private fun togglePin(memo: Memo) {
        lifecycleScope.launch { viewModel.togglePin(memo) }
    }

    private fun confirmDelete(memo: Memo) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.delete_confirm_title)
            .setMessage(R.string.delete_confirm_message)
            .setPositiveButton(R.string.confirm) { _, _ ->
                lifecycleScope.launch {
                    viewModel.delete(memo)
                    ReminderScheduler.cancel(this@MainActivity, memo.id)
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ---------- 新建 ----------
    private fun setupFab() {
        binding.fabAdd.setOnClickListener { openEditor(-1L) }
    }

    // ---------- 数据观察 ----------
    private fun observeMemos() {
        lifecycleScope.launch {
            viewModel.memos.collect { memos ->
                adapter.submitList(memos)
                binding.emptyView.visibility = if (memos.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    // ---------- 搜索 ----------
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        val searchView = menu.findItem(R.id.action_search).actionView as SearchView
        searchView.queryHint = getString(R.string.search_hint)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                viewModel.setQuery(query.orEmpty())
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                viewModel.setQuery(newText.orEmpty())
                return true
            }
        })
        return true
    }

    // ---------- Android 13+ 通知权限 ----------
    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
