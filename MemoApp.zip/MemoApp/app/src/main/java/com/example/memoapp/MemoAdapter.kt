package com.example.memoapp

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.memoapp.data.Memo
import com.example.memoapp.databinding.ItemMemoBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 列表适配器：使用 ListAdapter + DiffUtil 高效刷新
 */
class MemoAdapter(
    private val onItemClick: (Memo) -> Unit,
    private val onPinClick: (Memo) -> Unit,
    private val onDeleteClick: (Memo) -> Unit
) : ListAdapter<Memo, MemoAdapter.MemoViewHolder>(DiffCallback) {

    private val timeFormat = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())

    inner class MemoViewHolder(private val binding: ItemMemoBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(memo: Memo) {
            binding.tvTitle.text = memo.title.ifBlank { "（无标题）" }
            binding.tvContentPreview.text = memo.content
            binding.chipCategory.text = memo.category
            binding.tvTime.text = timeFormat.format(Date(memo.updatedAt))

            // 提醒图标：有提醒时间才显示
            binding.ivRemind.visibility = if (memo.remindAt != null) View.VISIBLE else View.GONE

            // 置顶图标：始终可点击，置顶时金色高亮
            val tintRes = if (memo.isPinned) R.color.pin_icon else R.color.text_secondary
            binding.ivPin.imageTintList = ColorStateList.valueOf(
                ContextCompat.getColor(binding.root.context, tintRes)
            )
            binding.ivPin.alpha = if (memo.isPinned) 1f else 0.35f
            binding.ivPin.contentDescription =
                binding.root.context.getString(if (memo.isPinned) R.string.unpin else R.string.pin)

            binding.root.setOnClickListener { onItemClick(memo) }
            binding.ivPin.setOnClickListener { onPinClick(memo) }
            binding.ivDelete.setOnClickListener { onDeleteClick(memo) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MemoViewHolder {
        val binding = ItemMemoBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return MemoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MemoViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    companion object DiffCallback : DiffUtil.ItemCallback<Memo>() {
        override fun areItemsTheSame(oldItem: Memo, newItem: Memo) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Memo, newItem: Memo) = oldItem == newItem
    }
}
