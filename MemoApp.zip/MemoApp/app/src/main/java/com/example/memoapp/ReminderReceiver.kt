package com.example.memoapp

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/**
 * 闹钟触发后弹出系统通知，点击通知跳转到该条备忘的编辑页
 */
class ReminderReceiver : BroadcastReceiver() {

    companion object {
        const val EXTRA_MEMO_ID = "extra_memo_id"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_CONTENT = "extra_content"

        private const val CHANNEL_ID = "memo_reminder_channel"
        private const val NOTIFICATION_ID_BASE = 2000
    }

    override fun onReceive(context: Context, intent: Intent) {
        val memoId = intent.getLongExtra(EXTRA_MEMO_ID, -1L)
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "备忘提醒"
        val content = intent.getStringExtra(EXTRA_CONTENT) ?: ""

        createChannel(context)

        // 点击通知打开编辑页并定位到该备忘
        val openIntent = Intent(context, EditMemoActivity::class.java).apply {
            putExtra(EditMemoActivity.EXTRA_MEMO_ID, memoId)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            memoId.toInt(),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(content.ifBlank { "你有一条备忘到期了" })
            .setStyle(NotificationCompat.BigTextStyle().bigText(content.ifBlank { "你有一条备忘到期了" }))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        try {
            NotificationManagerCompat.from(context)
                .notify(NOTIFICATION_ID_BASE + memoId.toInt(), notification)
        } catch (e: SecurityException) {
            // Android 13+ 用户未授予通知权限时静默失败
        }
    }

    private fun createChannel(context: Context) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            context.getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = context.getString(R.string.notification_channel_desc)
        }
        manager.createNotificationChannel(channel)
    }
}
