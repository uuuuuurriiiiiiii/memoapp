package com.example.memoapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * 备忘录实体（对应数据库表 memos）
 *
 * @param id        主键，自增
 * @param title     标题
 * @param content   正文内容
 * @param category  分类标签，可自定义
 * @param isPinned  是否置顶
 * @param remindAt  到期提醒时间（毫秒时间戳），null 表示不提醒
 * @param createdAt 创建时间
 * @param updatedAt 最后修改时间（列表按它降序排列）
 */
@Entity(tableName = "memos")
data class Memo(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val category: String = "默认",
    val isPinned: Boolean = false,
    val remindAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
