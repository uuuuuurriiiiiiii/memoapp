package com.example.memoapp.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * 备忘录数据访问对象（DAO）
 * 所有查询返回 Flow，界面通过 LiveData/StateFlow 自动刷新
 */
@Dao
interface MemoDao {

    @Insert
    suspend fun insert(memo: Memo): Long

    @Update
    suspend fun update(memo: Memo)

    @Delete
    suspend fun delete(memo: Memo)

    @Query("SELECT * FROM memos WHERE id = :id")
    suspend fun getById(id: Long): Memo?

    /** 全部备忘：置顶优先，其次按修改时间倒序 */
    @Query("SELECT * FROM memos ORDER BY isPinned DESC, updatedAt DESC")
    fun observeAll(): Flow<List<Memo>>

    /** 按关键词搜索标题和内容 */
    @Query(
        "SELECT * FROM memos WHERE (title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%') " +
            "ORDER BY isPinned DESC, updatedAt DESC"
    )
    fun search(query: String): Flow<List<Memo>>

    /** 按分类筛选 */
    @Query("SELECT * FROM memos WHERE category = :category ORDER BY isPinned DESC, updatedAt DESC")
    fun observeByCategory(category: String): Flow<List<Memo>>

    /** 分类内搜索 */
    @Query(
        "SELECT * FROM memos WHERE (title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%') " +
            "AND category = :category ORDER BY isPinned DESC, updatedAt DESC"
    )
    fun searchInCategory(query: String, category: String): Flow<List<Memo>>
}
