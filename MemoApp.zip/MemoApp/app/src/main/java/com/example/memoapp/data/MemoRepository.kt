package com.example.memoapp.data

import kotlinx.coroutines.flow.Flow

/**
 * 仓库层：为 ViewModel 屏蔽数据来源细节
 */
class MemoRepository(private val dao: MemoDao) {

    /**
     * 根据关键词 + 分类组合查询
     * category 为 null 或 "全部" 时表示不过滤分类
     */
    fun observeMemos(query: String, category: String?): Flow<List<Memo>> = when {
        category.isNullOrBlank() || category == "全部" ->
            if (query.isBlank()) dao.observeAll() else dao.search(query.trim())

        else ->
            if (query.isBlank()) dao.observeByCategory(category)
            else dao.searchInCategory(query.trim(), category)
    }

    suspend fun getById(id: Long): Memo? = dao.getById(id)

    suspend fun insert(memo: Memo): Long = dao.insert(memo)

    suspend fun update(memo: Memo) = dao.update(memo)

    suspend fun delete(memo: Memo) = dao.delete(memo)
}
