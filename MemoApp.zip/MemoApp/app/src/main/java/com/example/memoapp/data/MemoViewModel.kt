package com.example.memoapp.data

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * 主界面 ViewModel
 * 持有搜索关键词与分类两个状态，组合后驱动列表数据流
 */
@OptIn(ExperimentalCoroutinesApi::class)
class MemoViewModel(private val repository: MemoRepository) : ViewModel() {

    private val query = MutableStateFlow("")
    private val category = MutableStateFlow<String?>(null)

    /** 列表数据：置顶优先 + 修改时间倒序，搜索/分类变化时自动刷新 */
    val memos: StateFlow<List<Memo>> =
        combine(query, category) { q, c -> q to c }
            .flatMapLatest { (q, c) -> repository.observeMemos(q, c) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setQuery(value: String) {
        query.value = value
    }

    fun setCategory(value: String?) {
        category.value = value
    }

    /** 新增备忘，返回新记录的 id */
    suspend fun addMemo(title: String, content: String, categoryName: String, remindAt: Long?): Long {
        val now = System.currentTimeMillis()
        val memo = Memo(
            title = title,
            content = content,
            category = categoryName.ifBlank { "默认" },
            remindAt = remindAt,
            createdAt = now,
            updatedAt = now
        )
        return repository.insert(memo)
    }

    /** 更新备忘（刷新 updatedAt 与提醒时间） */
    suspend fun updateMemo(memo: Memo, title: String, content: String, categoryName: String, remindAt: Long?) {
        val updated = memo.copy(
            title = title,
            content = content,
            category = categoryName.ifBlank { "默认" },
            remindAt = remindAt,
            updatedAt = System.currentTimeMillis()
        )
        repository.update(updated)
    }

    /** 切换置顶状态 */
    suspend fun togglePin(memo: Memo) {
        repository.update(memo.copy(isPinned = !memo.isPinned, updatedAt = System.currentTimeMillis()))
    }

    /** 删除备忘 */
    suspend fun delete(memo: Memo) {
        repository.delete(memo)
    }

    /** ViewModel 工厂（构造需要 Repository） */
    class Factory(private val repository: MemoRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(MemoViewModel::class.java)) {
                return MemoViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
