package com.example.memoapp.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.memoapp.ReminderReceiver

/**
 * 到期提醒调度器：封装 AlarmManager 的设置与取消
 */
object ReminderScheduler {

    private const val REQUEST_CODE_BASE = 1000

    /** 为 memoId 生成稳定的 requestCode，便于单独取消某条提醒 */
    private fun requestCode(memoId: Long): Int = REQUEST_CODE_BASE + (memoId % 100000).toInt()

    /**
     * 设置提醒。
     * Android 12+ 若用户未授予"闹钟与提醒"精确闹钟权限，则降级为非精确提醒
     * （仍会触发，只是时间可能略有偏差）。
     */
    fun schedule(context: Context, memoId: Long, title: String, content: String, remindAt: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(ReminderReceiver.EXTRA_MEMO_ID, memoId)
            putExtra(ReminderReceiver.EXTRA_TITLE, title)
            putExtra(ReminderReceiver.EXTRA_CONTENT, content)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode(memoId),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, remindAt, pendingIntent)
        } else {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, remindAt, pendingIntent)
        }
    }

    /** 取消某条备忘的提醒 */
    fun cancel(context: Context, memoId: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode(memoId),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }
}
